# Exercise 6 – Modeling with WebGL
* Bonus: added 2 red flags one of each side of the goal
* added man united flags one of on top of the goal
* game is time-dependent instead of framerate- dependent


